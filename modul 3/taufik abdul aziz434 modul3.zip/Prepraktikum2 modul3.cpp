#include <stdio.h>

int main(){
	
	int a=502;
	
	for(int i=0;i<250;i++){
		a=a-2;
		printf("%i  ", a);
	}
	return 0;
}