#include <stdio.h>
int main(){
printf("\n50 mod 2: %d\n", (50%2));
printf("340 mod 3: %d\n", (340%3));
printf("45 * (125 mod 5): %d\n", (45*(125%5)));
printf("123 + (456 mod 7) - 89: %d\n", (123+(456%7)-89));}